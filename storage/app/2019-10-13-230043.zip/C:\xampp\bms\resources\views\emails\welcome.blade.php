<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
            <title>
                Curso laravel
            </title>
        </meta>
    </head>
    <body>
        <h2>
            Curso de laravel
        </h2>
        <div>
            bienvenido al sitio !! $name !!}
        </div>
    </body>
</html>