<?php

namespace App\Console\Commands;
use App\EnergiaPiso;

use DB;
use App\Piso;
use Illuminate\Console\Command;


class TendenciaPisoTres extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'energia:tres';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Este comando lee la energía consumida en el Piso 3';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
//ENERGIA ACUMULADA DURANTE LA ULTIMA HORA
        $energias = DB::connection('netx')
            ->table('dbo.NETX_DEFINITION')
            ->select(DB::raw('MAX(NUM_VALUE) as ener'), DB::raw('DATEPART(HOUR,[LOCAL_DATE]) as hora'))
            ->join('dbo.NETX_HISTORICAL_VALUE', 'NETX_DEFINITION.handle', '=', 'NETX_HISTORICAL_VALUE.handle')
            ->where('ITEMID', 'like', '%NETx\VIRTUAL\BMS\Energia\Piso 3\Energia%')
            ->where(DB::raw('CONVERT(date, LOCAL_DATE)'), '=', DB::raw('CONVERT(date, GETDATE())'))
            ->groupBy(DB::raw('DATEPART(HOUR,[LOCAL_DATE])'))
            ->get();
        foreach ($energias as $e) {
            $energia = $e->ener;
            $h       = $e->hora;
        };
        // dd($energias);

   $piso = DB::table('pisos')->select('id')->where('nombre', 'like', '%Piso 3%')->get();
        foreach ($piso as $p) {
            $pis = $p->id;
        }

        foreach ($piso as $p) {
            $piso_id = $p->id;

            //dd($piso_id);
        }
        //PICO

        $potencias = DB::connection('netx')
            ->table('dbo.NETX_DEFINITION')
            ->select(DB::raw('MAX(NUM_VALUE) as pot'), DB::raw('DATEPART(HOUR,[LOCAL_DATE]) as hora'))
            ->join('dbo.NETX_HISTORICAL_VALUE', 'NETX_DEFINITION.handle', '=', 'NETX_HISTORICAL_VALUE.handle')
            ->where('ITEMID', 'like', '%NETx\VIRTUAL\BMS\Energia\Piso 3\iluminacion\Potencia Max%')
            ->where(DB::raw('CONVERT(date, LOCAL_DATE)'), '=', DB::raw('CONVERT(date, GETDATE())'))
            ->groupBy(DB::raw('DATEPART(HOUR,[LOCAL_DATE])'))
            ->get();
        foreach ($potencias as $e) {
            $potencia = $e->pot;
        };
        //dd($potencia);
        //PROM TENSION Piso 3

        $tensiones = DB::connection('netx')
            ->table('dbo.NETX_DEFINITION')
            ->select(DB::raw('avg(NUM_VALUE) as promtension'), DB::raw('MAX(NUM_VALUE) as maxtension'), DB::raw('MIN(NUM_VALUE) as mintension'), DB::raw('DATEPART(HOUR,[LOCAL_DATE]) as hora'))
            ->join('dbo.NETX_HISTORICAL_VALUE', 'NETX_DEFINITION.handle', '=', 'NETX_HISTORICAL_VALUE.handle')
            ->where('ITEMID', 'like', '%NETx\XIO\Modbus\PM 3200 0\Holding Registers\3027%')
            ->where(DB::raw('CONVERT(date, LOCAL_DATE)'), '=', DB::raw('CONVERT(date, GETDATE())'))
            ->groupBy(DB::raw('DATEPART(HOUR,[LOCAL_DATE])'))
            ->get();
        foreach ($tensiones as $e) {
            $promt = $e->promtension;
            $maxt  = $e->maxtension;

            $mint = $e->mintension;

        };
        //dd($promt, $maxt, $mint);

        //ENERGIA ILUMINACION Piso 3

        $energiailu = DB::connection('netx')
            ->table('dbo.NETX_DEFINITION')
            ->select(DB::raw('MAX(NUM_VALUE) as eilu'), DB::raw('DATEPART(HOUR, [LOCAL_DATE]) as hora'))
            ->join('dbo.NETX_HISTORICAL_VALUE', 'NETX_DEFINITION.handle', ' = ', 'NETX_HISTORICAL_VALUE.handle')
            ->where('ITEMID', 'like', '%NETx\VIRTUAL\BMS\Energia\Piso 3\iluminacion\Energia%')
            ->where(DB::raw('CONVERT(date, LOCAL_DATE)'), '=', DB::raw('CONVERT(date, GETDATE())'))
            ->groupBy(DB::raw('DATEPART(HOUR, [LOCAL_DATE])'))
            ->get();
        foreach ($energiailu as $e) {
            $energiailum = $e->eilu;
        };
        //dd($energiailum);

        //PROM CORRIENTE Piso 3
        $promcorriente = DB::connection('netx')
            ->table('dbo.NETX_DEFINITION')
            ->select(DB::raw('AVG (NUM_VALUE) as F1'), DB::raw('AVG (NUM_VALUE) as F2'), DB::raw('AVG (NUM_VALUE) as F3'), DB::raw('DATEPART(HOUR,[LOCAL_DATE]) as hora'),DB::raw('CONVERT(date, LOCAL_DATE) as fecha'))
            ->join('dbo.NETX_HISTORICAL_VALUE', 'NETX_DEFINITION.handle', '=', 'NETX_HISTORICAL_VALUE.handle')
            ->where('ITEMID', 'like', '%NETx\XIO\Modbus\PM 3200 0\Holding Registers\2999%')
            ->where(DB::raw('CONVERT(date, LOCAL_DATE)'), '=', DB::raw('CONVERT(date, GETDATE())'))
            ->groupBy(DB::raw('DATEPART(HOUR,[LOCAL_DATE])'),DB::raw('CONVERT(date, LOCAL_DATE)'))
            ->get();
        foreach ($promcorriente as $e) {
            $f1      = $e->F1;
            $f2      = $e->F2;
            $f3      = $e->F3;
            $promcor = $f1 + $f2 + $f3;
            $date = \Carbon\Carbon::now();
        };

        //dd($promcorriente);

        //INSERT EN LA TABLA ENERGIA_PISO

        $energy = new energiaPiso(array(
            'energia'             => $energia,
            'pico'                => $potencia,
            'prom_tension'        => $promt,
            'max_tension'         => $maxt,
            'min_tension'         => $mint,
            'prom_corriente'      => $promcor,
            'energia_iluminacion' => $energiailum,
            'fecha'               => $date,
            'eficiencia'          => null,
            'piso_id'             => $piso_id,
            'created_at'          => null,
            'updated_at'          => null,
        ));
        $energy->save();

        \Log::info('ProbandoenergiaPiso 3' . \Carbon\Carbon::now());
    }
}
