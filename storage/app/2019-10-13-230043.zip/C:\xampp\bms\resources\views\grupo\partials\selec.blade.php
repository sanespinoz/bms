<div class="col-sm-6">
    <div class="form-group">
        {!! Form::select('piso',$pisos,null,['id'=>'piso']) !!}


{!! Form::select('sector',['placeholder'=>'Selecciona'],null,['id'=>'sector']) !!}
    </div>
</div>
