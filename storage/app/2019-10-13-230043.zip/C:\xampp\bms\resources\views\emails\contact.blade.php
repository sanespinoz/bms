<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
            <title>
                Mensaje Recibido
            </title>
    </head>
    <body>
        <p> Recibiste un mensaje de {!!$name!!} {!!$email!!}</p>
        <p><strong>Asunto:</strong> {!!$subject!!}</p>
        <p> Contenido {!!$mensaje!!}</p>
     
    </body>
</html>