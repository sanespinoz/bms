Sigue el link para resetear tu password: {{ url('/password/reset/'.$token) }}
